#include "cacheTestTools.h"
#include "myQsort.h"

int main(int argc, char *argv[]) {

   runSort(argc, argv, myQsort);

    return 0;
}
