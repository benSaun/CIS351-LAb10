#include "cacheTestTools.h"
#include "insertionSort.h"

int main(int argc, char *argv[]) {

    runSort(argc, argv, insertionSort);

    return 0;
}
